package com.mikaelfrancoeur.aoptalk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AoptalkApplicationTests {

	@Test
	void contextLoads() {
	}

}
