package com.mikaelfrancoeur.aoptalk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AoptalkApplication {

	public static void main(String[] args) {
		SpringApplication.run(AoptalkApplication.class, args);
	}

}
